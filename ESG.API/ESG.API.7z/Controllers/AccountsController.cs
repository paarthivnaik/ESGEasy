﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESG.API.Controllers
{

    public class AccountsController : BaseController
    {
    }
}
